"""
@author Yannick Chevalier
@date 2026
"""

class Contexts:
    contexts=set([]) # type set
    def __init__(self,ctxts=[]):
        self.contexts=set(ctxts)
    def add(self,ctxt):
        self.contexts.add(ctxt)
    def printContexts(self): # pour debug
        print(self.contexts)
    def compare(self,aContext):
        lowerOrEq=(self.contexts <= aContext.contexts)
        greaterOrEq=(self.contexts >= aContext.contexts)
        if lowerOrEq and greaterOrEq:
            return 0 # equal
        elif lowerOrEq:
            return -1
        elif greaterOrEq:
            return 1
        else:
            return None


class SecurityLevel:
    hierarchy=None
    contexts=None
    level=None
    def __init__(self,classification=hierarchy,ctxts=[],level=None):
        self.contexts=Contexts(ctxts)
        self.level=level
        self.hierarchy=classification
    def compare(self,aSecurityLevel):
        if not ( self.hierarchy == aSecurityLevel.hierarchy):
            return None
        ctxtcmp=contexts.compare(aSecurityLevel.contexts)
        levelcmp=self.hierarchy.compare(self.level,aSecurityLevel.level)
        # if either is incomparable, the result is incomparable
        if ctxtcmp is None or levelcmp is None:
            return None
        # if they are both non-zero but of a different sign, the result is None
        if ctxtcmp * levelcmp < 0:
            return None
        # if they agree (or equal)...
        return ctxtcmp+levelcmp
    def printLevel(self):
        print(f'hierarchy={self.hierarchy}, contexts={self.contexts.printContexts()}, level={self.level}')

class Classification:
    # classification is a dictionary that stores, for each security
    # level, all the levels strictly below it
    classification=None
    def __init__(self):
        self.classification=dict([])
    def addClassificationLevel(self,level,above=[]):
        # adds a level above those listed
        s= set(above)
        for lvl in above:
            s_level=self.classification.get(lvl)
            if s_level is not None:
                s=s.union(s_level)
        if level in s:
            raise Exception (f'Error, level {level} is already defined and below one of the levels it should be above')
        self.classification[level]=s
    def securityLevel(self,ctxts=[],level=None):
        if level not in self.classification:
            raise Exception(f'Level {level} is not known in this classification')
        return SecurityLevel(classification=self,ctxts=ctxts,level=level)
    def compare(self,level1,level2):
        if level1 == level2:
            return 0
        s1 = self.classification.get(level1)
        s2 = self.classification.get(level2)
        if s1 is None:
            raise Exception (f'Error, level {level1} is not defined in this classification')
        if s2 is None:
            raise Exception (f'Error, level {level2} is not defined in this classification')
        if level1 == level2:
            return 0
        if level1 in s2:
            return -1
        if level2 in s1:
            return 1
        return None


class Controleur(Classification):
    def __init__(self):
        super().__init()
    # ajoutez votre code ici
